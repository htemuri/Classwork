#!/bin/bash

pip3 install scipy
pip3 install numpy
python3 main.py