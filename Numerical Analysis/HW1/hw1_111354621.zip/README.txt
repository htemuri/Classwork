This program uses python3
Make sure to install scipy and numpy :)

scipy: $ pip3 install scipy
numpy: $ pip3 install numpy

To run the program:
$ python3 main.py

Also included is a shell script that the user can run
to execute the program
$ ./install.sh